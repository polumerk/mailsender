﻿using MailSender.Domain.Entities;

namespace MailSender.Infrastructure.Repositories.Interfaces
{
    public interface IStatusHistoryRepository : IBaseRepository<StatusHistory>
    {
    }
}