namespace MailSender.Domain.Enums;

public enum TypeEnum
{
    HtmlEmail = 1,
    HtmlFile,
    DocFile,
    Phone
}