﻿namespace MailSender.Domain.Enums
{
    /// <summary>
    /// Способ отправки sms
    /// </summary>
    public enum EmailSenderTypeEnum
    {
        SMTP,
        POP3
    }
}