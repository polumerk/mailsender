﻿namespace MailSender.Domain.DTOs.EntitiesDTO
{
    public class WhiteListUpdateDTO
    {
        public string Email { get; set; }
        public string Description { get; set; }
    }
}