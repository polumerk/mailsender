﻿namespace MailSender.Domain.DTOs.Broker.Receive
{
    public class MailAttachmentDTO
    {
        public FileAttachmentDTO File { get; set; }
    }
}