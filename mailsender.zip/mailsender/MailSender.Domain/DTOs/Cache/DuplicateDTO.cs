﻿using System;

namespace MailSender.Domain.DTOs.Cache
{
    public class DuplicateDTO
    {
        public DateTime CreateDate { get; set; }
    }
}